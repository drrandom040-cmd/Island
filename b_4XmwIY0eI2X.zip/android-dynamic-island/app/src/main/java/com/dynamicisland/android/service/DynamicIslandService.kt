package com.dynamicisland.android.service

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.animation.OvershootInterpolator
import androidx.core.app.NotificationCompat
import com.dynamicisland.android.MainActivity
import com.dynamicisland.android.R
import com.dynamicisland.android.databinding.LayoutDynamicIslandBinding

class DynamicIslandService : Service() {

    private lateinit var windowManager: WindowManager
    private lateinit var binding: LayoutDynamicIslandBinding
    private lateinit var params: WindowManager.LayoutParams
    private val handler = Handler(Looper.getMainLooper())

    private var isExpanded = false
    private var currentWidth = COLLAPSED_WIDTH
    private var currentHeight = COLLAPSED_HEIGHT

    private val notificationReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val title = intent?.getStringExtra("title") ?: "Notification"
            val text = intent?.getStringExtra("text") ?: ""
            val packageName = intent?.getStringExtra("package") ?: ""
            showNotification(title, text, packageName)
        }
    }

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        createNotificationChannel()
        startForeground(NOTIFICATION_ID, createForegroundNotification())
        createDynamicIsland()
        registerReceiver()
    }

    private fun registerReceiver() {
        val filter = IntentFilter("com.dynamicisland.NOTIFICATION_POSTED")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(notificationReceiver, filter, RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(notificationReceiver, filter)
        }
    }

    private fun createDynamicIsland() {
        binding = LayoutDynamicIslandBinding.inflate(LayoutInflater.from(this))

        val layoutFlag = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        params = WindowManager.LayoutParams(
            COLLAPSED_WIDTH,
            COLLAPSED_HEIGHT,
            layoutFlag,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            y = getStatusBarHeight()
        }

        windowManager.addView(binding.root, params)
        setupTouchListener()
        setupClickListeners()
    }

    private fun setupTouchListener() {
        binding.root.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    // Visual feedback
                    binding.islandContainer.animate()
                        .scaleX(0.95f)
                        .scaleY(0.95f)
                        .setDuration(100)
                        .start()
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    binding.islandContainer.animate()
                        .scaleX(1f)
                        .scaleY(1f)
                        .setDuration(100)
                        .start()
                    
                    if (event.action == MotionEvent.ACTION_UP) {
                        toggleExpand()
                    }
                    true
                }
                else -> false
            }
        }
    }

    private fun setupClickListeners() {
        binding.closeButton.setOnClickListener {
            collapse()
        }
    }

    private fun toggleExpand() {
        if (isExpanded) {
            collapse()
        } else {
            expand()
        }
    }

    private fun expand() {
        if (isExpanded) return
        isExpanded = true

        animateSize(COLLAPSED_WIDTH, EXPANDED_WIDTH, COLLAPSED_HEIGHT, EXPANDED_HEIGHT) {
            binding.expandedContent.visibility = View.VISIBLE
            binding.expandedContent.alpha = 0f
            binding.expandedContent.animate()
                .alpha(1f)
                .setDuration(150)
                .start()
        }

        // Auto collapse after 5 seconds
        handler.postDelayed({ collapse() }, 5000)
    }

    private fun collapse() {
        if (!isExpanded) return
        isExpanded = false
        handler.removeCallbacksAndMessages(null)

        binding.expandedContent.animate()
            .alpha(0f)
            .setDuration(100)
            .withEndAction {
                binding.expandedContent.visibility = View.GONE
            }
            .start()

        animateSize(currentWidth, COLLAPSED_WIDTH, currentHeight, COLLAPSED_HEIGHT)
    }

    private fun animateSize(
        fromWidth: Int,
        toWidth: Int,
        fromHeight: Int,
        toHeight: Int,
        onComplete: (() -> Unit)? = null
    ) {
        val widthAnimator = ValueAnimator.ofInt(fromWidth, toWidth)
        val heightAnimator = ValueAnimator.ofInt(fromHeight, toHeight)

        widthAnimator.addUpdateListener { animator ->
            currentWidth = animator.animatedValue as Int
            params.width = currentWidth
            try {
                windowManager.updateViewLayout(binding.root, params)
            } catch (e: Exception) {
                // View might be removed
            }
        }

        heightAnimator.addUpdateListener { animator ->
            currentHeight = animator.animatedValue as Int
            params.height = currentHeight
            try {
                windowManager.updateViewLayout(binding.root, params)
            } catch (e: Exception) {
                // View might be removed
            }
        }

        heightAnimator.addListener(object : AnimatorListenerAdapter() {
            override fun onAnimationEnd(animation: Animator) {
                onComplete?.invoke()
            }
        })

        widthAnimator.apply {
            duration = 300
            interpolator = OvershootInterpolator(0.8f)
            start()
        }

        heightAnimator.apply {
            duration = 300
            interpolator = OvershootInterpolator(0.8f)
            start()
        }
    }

    fun showNotification(title: String, text: String, packageName: String) {
        handler.post {
            binding.notificationTitle.text = title
            binding.notificationText.text = text
            
            // Show notification pill animation
            expandForNotification()
        }
    }

    private fun expandForNotification() {
        if (isExpanded) return

        // Temporary expand to show notification
        val notificationWidth = (COLLAPSED_WIDTH * 1.8).toInt()
        
        animateSize(currentWidth, notificationWidth, currentHeight, COLLAPSED_HEIGHT + 20)
        
        handler.postDelayed({
            if (!isExpanded) {
                animateSize(currentWidth, COLLAPSED_WIDTH, currentHeight, COLLAPSED_HEIGHT)
            }
        }, 3000)
    }

    private fun getStatusBarHeight(): Int {
        var result = 0
        val resourceId = resources.getIdentifier("status_bar_height", "dimen", "android")
        if (resourceId > 0) {
            result = resources.getDimensionPixelSize(resourceId)
        }
        return result + 8 // Add small padding
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Dynamic Island Service",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Keeps Dynamic Island running"
                setShowBadge(false)
            }
            val notificationManager = getSystemService(NotificationManager::class.java)
            notificationManager.createNotificationChannel(channel)
        }
    }

    private fun createForegroundNotification(): Notification {
        val intent = Intent(this, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            this, 0, intent,
            PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Dynamic Island Active")
            .setContentText("Tap to configure")
            .setSmallIcon(R.drawable.ic_island)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .setSilent(true)
            .build()
    }

    override fun onDestroy() {
        super.onDestroy()
        try {
            unregisterReceiver(notificationReceiver)
            windowManager.removeView(binding.root)
        } catch (e: Exception) {
            // Already removed
        }
        handler.removeCallbacksAndMessages(null)
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        private const val NOTIFICATION_ID = 1
        private const val CHANNEL_ID = "dynamic_island_channel"
        
        private const val COLLAPSED_WIDTH = 280
        private const val COLLAPSED_HEIGHT = 90
        private const val EXPANDED_WIDTH = 600
        private const val EXPANDED_HEIGHT = 400
    }
}
